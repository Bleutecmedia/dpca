-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-08-2020 a las 19:25:33
-- Versión del servidor: 10.4.13-MariaDB
-- Versión de PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dialisis`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('pmm3oko5gs45rthmlo7dg1kpgas99o5c', '127.0.0.1', 1597101431, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539373130313433313b6769647c733a32313a22313030303935303636393031303933393735363839223b),
('uu4hsc1vqff6foj6h8kel2h4qgnd1gul', '127.0.0.1', 1597101543, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539373130313534333b6769647c733a32313a22313030303935303636393031303933393735363839223b6964656e746974797c733a31383a226973632e616c656a40676d61696c2e636f6d223b656d61696c7c733a31383a226973632e616c656a40676d61696c2e636f6d223b757365725f69647c733a313a2231223b6f6c645f6c6173745f6c6f67696e7c733a31303a2231353937313031313330223b6c6173745f636865636b7c693a313539373130313534333b),
('37aee89hterf6mvrs6mf7dpp9np52u9f', '127.0.0.1', 1597101615, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539373130313631353b6964656e746974797c733a32323a2277696c736f6e63616c7a6f6e40676d61696c2e636f6d223b656d61696c7c733a32323a2277696c736f6e63616c7a6f6e40676d61696c2e636f6d223b757365725f69647c733a313a2233223b6f6c645f6c6173745f6c6f67696e7c733a31303a2231353937303638353038223b6c6173745f636865636b7c693a313539373130313631353b),
('a4c65ueo6eftqn6lif6152s4vohlfp14', '127.0.0.1', 1597102448, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539373130323434383b6769647c733a32313a22313030303935303636393031303933393735363839223b),
('spfimi6na2irmaspnc5snocvpqlcuvie', '127.0.0.1', 1597102753, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539373130323735333b6769647c733a32313a22313030303935303636393031303933393735363839223b),
('p06ci2lo3704r2k7nc3smtq50n7hkoi4', '127.0.0.1', 1597102868, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539373130323836383b6769647c733a32313a22313030303935303636393031303933393735363839223b6964656e746974797c733a31383a226973632e616c656a40676d61696c2e636f6d223b656d61696c7c733a31383a226973632e616c656a40676d61696c2e636f6d223b757365725f69647c733a313a2231223b6f6c645f6c6173745f6c6f67696e7c733a31303a2231353937313032383637223b6c6173745f636865636b7c693a313539373130323836383b),
('7li2fe7fdu7sudnphaftc6q9q3guk6rj', '127.0.0.1', 1597103137, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539373130333133373b6964656e746974797c733a31383a226973632e616c656a40676d61696c2e636f6d223b656d61696c7c733a31383a226973632e616c656a40676d61696c2e636f6d223b757365725f69647c733a313a2231223b6f6c645f6c6173745f6c6f67696e7c733a31303a2231353937313033313337223b6c6173745f636865636b7c693a313539373130333133373b),
('gci2nh057larldeo0efctqqq02gmk2jt', '127.0.0.1', 1597103448, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539373130333434383b6964656e746974797c733a31383a226973632e616c656a40676d61696c2e636f6d223b656d61696c7c733a31383a226973632e616c656a40676d61696c2e636f6d223b757365725f69647c733a313a2231223b6f6c645f6c6173745f6c6f67696e7c733a31303a2231353937313033313337223b6c6173745f636865636b7c693a313539373130333133373b6769647c733a32313a22313030303935303636393031303933393735363839223b61646d696e7c733a313a2231223b70686f746f7c733a38313a2268747470733a2f2f6c68332e676f6f676c6575736572636f6e74656e742e636f6d2f612d2f414f683134476a3568364e437451696465666d57426b4e39685f374c76334538466f69323669734c696f697a223b),
('a6618016oeh9570vl8a852uci8cgbd8n', '127.0.0.1', 1597103977, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539373130333937373b6964656e746974797c733a31383a226973632e616c656a40676d61696c2e636f6d223b656d61696c7c733a31383a226973632e616c656a40676d61696c2e636f6d223b757365725f69647c733a313a2231223b6f6c645f6c6173745f6c6f67696e7c733a31303a2231353937313033313337223b6c6173745f636865636b7c693a313539373130333133373b6769647c733a32313a22313030303935303636393031303933393735363839223b61646d696e7c733a313a2231223b70686f746f7c733a38313a2268747470733a2f2f6c68332e676f6f676c6575736572636f6e74656e742e636f6d2f612d2f414f683134476a3568364e437451696465666d57426b4e39685f374c76334538466f69323669734c696f697a223b),
('juonntbscqqnf1opfc1h31jjojl9g3at', '127.0.0.1', 1597104411, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539373130343431313b6964656e746974797c733a31383a226973632e616c656a40676d61696c2e636f6d223b656d61696c7c733a31383a226973632e616c656a40676d61696c2e636f6d223b757365725f69647c733a313a2231223b6f6c645f6c6173745f6c6f67696e7c733a31303a2231353937313033313337223b6c6173745f636865636b7c693a313539373130333133373b6769647c733a32313a22313030303935303636393031303933393735363839223b61646d696e7c733a313a2231223b70686f746f7c733a38313a2268747470733a2f2f6c68332e676f6f676c6575736572636f6e74656e742e636f6d2f612d2f414f683134476a3568364e437451696465666d57426b4e39685f374c76334538466f69323669734c696f697a223b),
('t8bnhu2e5ie77kmf4409jv8kftnktbh0', '127.0.0.1', 1597105325, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539373130353332353b6964656e746974797c733a31383a226973632e616c656a40676d61696c2e636f6d223b656d61696c7c733a31383a226973632e616c656a40676d61696c2e636f6d223b757365725f69647c733a313a2231223b6f6c645f6c6173745f6c6f67696e7c733a31303a2231353937313033313337223b6c6173745f636865636b7c693a313539373130333133373b6769647c733a32313a22313030303935303636393031303933393735363839223b61646d696e7c733a313a2231223b70686f746f7c733a38313a2268747470733a2f2f6c68332e676f6f676c6575736572636f6e74656e742e636f6d2f612d2f414f683134476a3568364e437451696465666d57426b4e39685f374c76334538466f69323669734c696f697a223b),
('c4ubnj344h24jd0pn6t45esjj5q8kkoo', '127.0.0.1', 1597105364, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539373130353336343b6964656e746974797c733a31383a226973632e616c656a40676d61696c2e636f6d223b656d61696c7c733a31383a226973632e616c656a40676d61696c2e636f6d223b757365725f69647c733a313a2231223b6f6c645f6c6173745f6c6f67696e7c733a31303a2231353937313035333633223b6c6173745f636865636b7c693a313539373130353336343b),
('j98b868djgmqslsg65o95vodtam1rhjc', '127.0.0.1', 1597105513, 0x5f5f63695f6c6173745f726567656e65726174657c693a313539373130353531333b6d6573736167657c733a33363a223c703e53657369c3b36e2066696e616c697a61646120636f6e20c3a97869746f3c2f703e223b5f5f63695f766172737c613a313a7b733a373a226d657373616765223b733a333a226f6c64223b7d);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config`
--

CREATE TABLE `config` (
  `confid` int(11) NOT NULL COMMENT 'ID de la Configuración',
  `conf_userid` int(11) NOT NULL DEFAULT 1 COMMENT 'ID del Usuario del que es la configuración',
  `conf_paciente` varchar(300) DEFAULT NULL COMMENT 'Nombre del Paciente',
  `conf_intercambios` tinyint(4) DEFAULT 4 COMMENT 'Total de Itercambios por día'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `config`
--

INSERT INTO `config` (`confid`, `conf_userid`, `conf_paciente`, `conf_intercambios`) VALUES
(1, 1, NULL, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `intercambios`
--

CREATE TABLE `intercambios` (
  `interid` int(11) NOT NULL COMMENT 'ID del Intercambio',
  `in_solid` smallint(6) NOT NULL COMMENT 'ID del tipo de Solución',
  `in_fecha` int(10) DEFAULT 0 COMMENT 'Fecha de apertura del Proceso DPCA',
  `in_peso_inicial` float DEFAULT 0 COMMENT 'Peso de la Bolsa que entra',
  `in_peso_final` float DEFAULT 0 COMMENT 'Peso de la Bolsa de salida',
  `in_hora_sale_inicio` int(10) DEFAULT 0 COMMENT 'Unix timespan del inicio de la Salida',
  `in_hora_sale_termina` int(10) DEFAULT 0 COMMENT 'Unix timespan del término de la Salida',
  `in_hora_entra_inicio` int(10) DEFAULT 0 COMMENT 'Unix timespan del inicio de la Entrada',
  `in_hora_entra_termina` int(10) DEFAULT 0 COMMENT 'Unix timespan del fin de la Entrada',
  `in_userid` int(11) UNSIGNED NOT NULL COMMENT 'ID del Usuario que procesa',
  `in_status` tinyint(4) DEFAULT 1 COMMENT '1 -> En proceso, 2-> Terminado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Historial de Intercambios de las Diálisis';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `soluciones`
--

CREATE TABLE `soluciones` (
  `solid` smallint(6) NOT NULL COMMENT 'ID de la Solución',
  `sol_color` varchar(12) DEFAULT NULL COMMENT 'Color',
  `sol_concentra` varchar(10) DEFAULT NULL COMMENT 'Tipo de concentración'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Catálogo de Soluciones';

--
-- Volcado de datos para la tabla `soluciones`
--

INSERT INTO `soluciones` (`solid`, `sol_color`, `sol_concentra`) VALUES
(1, 'N/A', '0.0%'),
(2, 'AMARILLA', '1.5%'),
(3, 'VERDE', '2.5%');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(254) NOT NULL,
  `activation_selector` varchar(255) DEFAULT NULL,
  `activation_code` varchar(255) DEFAULT NULL,
  `forgotten_password_selector` varchar(255) DEFAULT NULL,
  `forgotten_password_code` varchar(255) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_selector` varchar(255) DEFAULT NULL,
  `remember_code` varchar(255) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `cellphone` varchar(20) NOT NULL,
  `storeid` int(11) NOT NULL DEFAULT 0 COMMENT 'ID del usuario en gallospro.com',
  `content` int(10) NOT NULL DEFAULT 0,
  `photo` varchar(160) DEFAULT NULL COMMENT 'URL de la Foto del Usuario de Google',
  `profile` varchar(160) DEFAULT NULL COMMENT 'URL del Perfil del Usuario de Google',
  `gid` varchar(60) DEFAULT NULL COMMENT 'UID del Usuario de Google',
  `lang` varchar(4) DEFAULT NULL COMMENT 'Locale del Usuario de Google',
  `verified` tinyint(1) DEFAULT NULL COMMENT 'Email de Google verificado',
  `code` varchar(60) DEFAULT NULL COMMENT 'Firebase UID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`, `cellphone`, `storeid`, `content`, `photo`, `profile`, `gid`, `lang`, `verified`, `code`) VALUES
(1, '127.0.0.1', 'isc.alej', '$2y$12$501Cu62Wo1l11L.DXgRe2eA4MvgySbecil0cC2NkeZpXc9ANEcGI6', 'isc.alej@gmail.com', NULL, NULL, NULL, NULL, NULL, '3f814a541362b1ee062f950e90b5a969e2bb243f', '$2y$10$4hyllUjKYfQrT0WBqHhiG.IDbkFZvLzaRnJgJW2.0UHaiuph1uBaG', 1596840300, 1597105364, 1, 'Dandy', 'del Congo', NULL, NULL, '', 0, 0, 'https://lh3.googleusercontent.com/a-/AOh14Gj5h6NCtQidefmWBkN9h_7Lv3E8Foi26isLioiz', '', NULL, 'es', 1, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 2);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indices de la tabla `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`confid`),
  ADD UNIQUE KEY `confid_UNIQUE` (`confid`);

--
-- Indices de la tabla `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `intercambios`
--
ALTER TABLE `intercambios`
  ADD PRIMARY KEY (`interid`),
  ADD KEY `FK_intercambios_soluciones_solid` (`in_solid`),
  ADD KEY `FK_intercambios_users_id` (`in_userid`);

--
-- Indices de la tabla `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `soluciones`
--
ALTER TABLE `soluciones`
  ADD PRIMARY KEY (`solid`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_email` (`email`),
  ADD UNIQUE KEY `uc_activation_selector` (`activation_selector`),
  ADD UNIQUE KEY `uc_forgotten_password_selector` (`forgotten_password_selector`),
  ADD UNIQUE KEY `uc_remember_selector` (`remember_selector`);

--
-- Indices de la tabla `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `config`
--
ALTER TABLE `config`
  MODIFY `confid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID de la Configuración', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `intercambios`
--
ALTER TABLE `intercambios`
  MODIFY `interid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID del Intercambio';

--
-- AUTO_INCREMENT de la tabla `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `intercambios`
--
ALTER TABLE `intercambios`
  ADD CONSTRAINT `FK_intercambios_soluciones_solid` FOREIGN KEY (`in_solid`) REFERENCES `soluciones` (`solid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_intercambios_users_id` FOREIGN KEY (`in_userid`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
